#include <stdio.h>//Importar la funcion print(La libreria).

//Void no devuelve nada
int main(){
	printf('Filyan karagoz Potra\n');
	return 0;
}
// Es lo mismo que 
void main(){
	printf('Filyan karagoz Potra\n');
	return;
}

//gcc compilador