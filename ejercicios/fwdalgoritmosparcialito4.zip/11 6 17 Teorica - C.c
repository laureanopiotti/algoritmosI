/* 
Pedir memoria al sistema operativo.
Cada variable debe ser declarada antes, y las que se van a declarar mas adelante tambien

Declaro y defino.

x = 12; //Declaracion

si no la defino nunca, tengo que eliminarla porque ocupa memoria

Numeros enteros admiten no tener signo (unsigned).

float -> 32 bits, no tiene tanta presicion
double -> 64 bits,  tiene mayor presicion

sizeof(x) -> cant que ocupa en bytes de memoria		*/

int sumar (int a, int b){
	return a + b
}

double x;
x=sumar(4.8,12.3);
